"""IT Survivor: punto de entrada (escritorio y navegador)."""
import asyncio

from src.game import run_game

asyncio.run(run_game())
